## Notice:

This is the original source, binaries, and documentation as retrieved from:

https://www.bouncycastle.org/download/bouncy-castle-c-fips/

on 2025-06-19.

